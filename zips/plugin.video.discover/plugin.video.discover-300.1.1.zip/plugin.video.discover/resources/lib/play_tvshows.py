import re, json, urllib, datetime
import xbmc
from resources.lib import text
from resources.lib import dialogs
from resources.lib import meta_info
from resources.lib import play_base
from resources.lib import properties
from resources.lib import meta_players

def play_episode(id, season, episode):
    from resources.lib.TheTVDB import TVDB
    id = int(id)
    season = int(season)
    episode = int(episode)
    dbid = xbmc.getInfoLabel('ListItem.DBID')
    try: dbid = int(dbid)
    except: dbid = None
    show = TVDB[id]
    show_info = meta_info.get_tvshow_metadata_tvdb(show, banners=False)
    play_plugin = meta_players.ADDON_SELECTOR.id
    PLAYERS = meta_players.get_players('tvshows')
    players = [p for p in PLAYERS if p.id == play_plugin] or PLAYERS
    if not players or len(players) == 0:
        xbmc.executebuiltin('Action(Info)')
        play_base.action_cancel()
        return
    trakt_ids = play_base.get_trakt_ids('tvdb', id, show['seriesname'], 'show', show.get('year', 0))
    params = {}
    for lang in meta_players.get_needed_langs(players):
        tvdb_data = show
        if tvdb_data['seriesname'] is None: continue
        episode_parameters = get_episode_parameters(tvdb_data, season, episode)
        if episode_parameters is not None: params[lang] = episode_parameters
        else:
            if trakt_ids['tmdb'] != None and trakt_ids['tmdb'] != '':
                return tmdb_play_episode(trakt_ids['tmdb'], season, episode)
            elif trakt_ids['tvdb'] == None or trakt_ids['tvdb'] == '':
                return dialogs.ok('Information not found for:', '%s - S%sE%s' % (show_info['name'], season, episode))
            else: return dialogs.ok('Information not found for:', '%s - S%sE%s' % (show_info['name'], season, episode))
        if trakt_ids != None: params[lang].update(trakt_ids)
        params[lang]['info'] = show_info
        params[lang] = text.to_unicode(params[lang])
    link = play_base.on_play_video(players, params, trakt_ids)
    if link:
        properties.set_property('data', json.dumps({'dbid': dbid, 'tvdb': id, 'season': season, 'episode': episode}))
        season_info = meta_info.get_season_metadata_tvdb(show_info, show[season], banners=False)
        episode_info = meta_info.get_episode_metadata_tvdb(season_info, show[season][episode])
        play_base.action_play({'label': episode_info['title'],
                               'path': link,
                               'info': episode_info,
                               'is_playable': True,
                               'info_type': 'video',
                               'thumbnail': episode_info['poster'],
                               'poster': episode_info['poster'],
                               'properties': {'fanart_image': episode_info['fanart']}})

def tmdb_play_episode(id, season, episode):
    from resources.lib.TheMovieDB import TV, TV_Seasons, TV_Episodes
    tried = 'tvdb'
    id = int(id)
    season = int(season)
    episode = int(episode)
    dbid = xbmc.getInfoLabel('ListItem.DBID')
    try: dbid = int(dbid)
    except: dbid = None
    show = TV(id).info(language='en', append_to_response='external_ids,images,similar,videos')
    if 'first_air_date' in show and show['first_air_date'] != None: year = show['first_air_date'][:4]
    else: year = None
    trakt_ids = play_base.get_trakt_ids('tmdb', id)
    if 'status_code' in show: return trakt_play_episode(trakt_ids['trakt'], season, episode)
    if 'name' in show: title = show['name']
    else: title = None
    show_info = meta_info.get_tvshow_metadata_tmdb(show)
    title = show_info['name']
    preason = TV_Seasons(id, season).info(language='en', append_to_response='external_ids,images,similar,videos')
    if 'The resource you requested could not be found' in str(preason): return trakt_play_episode(trakt_ids['trakt'], season, episode)
    season_info = meta_info.get_season_metadata_tmdb(show_info, preason)
    prepisode = TV_Episodes(id, season, episode).info(language='en', append_to_response='external_ids,images,similar,videos')
    if prepisode == '{u"status_code": 34, u"status_message": u"The resource you requested could not be found."}': return trakt_play_episode(trakt_ids['tmdb'], season, episode)
    episode_info = meta_info.get_episode_metadata_tmdb(season_info, prepisode)
    if show_info['poster'] != None and show_info['poster'] != '': show_poster = show_info['poster']
    else: show_poster = ''
    if show_info['fanart'] != None and show_info['fanart'] != '': show_fanart = show_info['fanart']
    else: show_fanart = ''
    episodes = preason['episodes']
    items = []
    play_plugin = meta_players.ADDON_SELECTOR.id
    players = meta_players.get_players('tvshows')
    players = [p for p in players if p.id == play_plugin] or players
    if not players: return xbmc.executebuiltin('Action(Info)')
    trakt_ids = play_base.get_trakt_ids('tmdb', id, show_info['name'], 'show', show['first_air_date'][:4])
    params = {}
    for lang in meta_players.get_needed_langs(players):
        if show['name'] is None: continue
        episode_parameters = get_tmdb_episode_parameters(show, preason, prepisode)
        if episode_parameters is not None: params[lang] = episode_parameters
        else:
            if trakt_ids['trakt'] != None and trakt_ids['trakt'] != '': return trakt_play_episode(trakt_ids['trakt'], season, episode)
            else:
                title = 'Episode information not found'
                msg = 'No TMDb information found for %s - S%sE%s' % (show_info['name'], season, episode)
                dialogs.ok(title, msg)
                return
        if trakt_ids != None: params[lang].update(trakt_ids)
        params[lang]['info'] = show_info
        params[lang] = text.to_unicode(params[lang])
    link = play_base.on_play_video(players, params, trakt_ids)
    if link:
        properties.set_property('data', json.dumps({'dbid': dbid, 'tmdb': id, 'season': season, 'episode': episode}))
        episode_metadata = meta_info.get_episode_metadata_tmdb(season_info, prepisode)
        play_base.action_play({'label': episode_info['title'],
                               'path': link,
                               'info': [],
                               'is_playable': True,
                               'info_type': 'video',
                               'thumbnail': episode_info['poster'],
                               'poster': episode_info['poster'],
                               'properties': {'fanart_image': str(show_info['fanart'])}})

def trakt_play_episode(id, season, episode):
    from resources.lib.Trakt import get_show, get_season, get_seasons, get_episode
    id = int(id)
    season = int(season)
    episode = int(episode)
    show = None
    preason = None
    prepisode = None
    dbid = xbmc.getInfoLabel('ListItem.DBID')
    try: dbid = int(dbid)
    except: dbid = None
    show = get_show(id)
    if 'name' in show: show_title = show['name']
    elif 'title' in show: show_title = show['title']
    if show:
        if show['first_aired']: year = show['first_aired'][:4]
        else: year = None
        trakt_ids = play_base.get_trakt_ids('trakt', id, show_title, 'show', year)
        preason = get_season(id, season)
        if preason: prepisode = get_episode(id, season, episode)
        elif not preason and season > 1900: 
            seasons = get_seasons(id)
            for item in seasons:
                if item['first_aired'] != None:
                    if int(item['first_aired'][:4]) == season: 
                        season_number = item['number']
                        preason = get_season(id, season_number)
    if not prepisode or not preason or not show: return tvmaze_play_episode(show_title, season, episode)
    show_info = meta_info.get_tvshow_metadata_trakt(show)
    season_info = meta_info.get_season_metadata_trakt(show_info, preason)
    episode_info = meta_info.get_episode_metadata_trakt(season_info, prepisode)
    title = show_info['name']
    if show_info['poster'] != None and show_info['poster'] != '': show_poster = show_info['poster']
    else: show_poster = ''
    if show_info['fanart'] != None and show_info['fanart'] != '': show_fanart = show_info['fanart']
    else: show_fanart = ''
    items = []
    play_plugin = meta_players.ADDON_SELECTOR.id
    players = meta_players.get_players('tvshows')
    players = [p for p in players if p.id == play_plugin] or players
    if not players: return xbmc.executebuiltin('Action(Info)')
    params = {}
    for lang in meta_players.get_needed_langs(players):
        if show['name'] is None: continue
        episode_parameters = get_trakt_episode_parameters(show, preason, prepisode)
        if episode_parameters is not None: params[lang] = episode_parameters
        else:
            title = 'Episode information not found'
            if trakt_ids['tmdb'] != None and trakt_ids['tmdb'] != '' and tried != 'tmdb': 
                tried = 'tmdb'
                return tvdb_play_episode(trakt_ids['tvdb'], season, episode)
            elif tried == 'tmdb':
                msg = 'No TVDb or TMDb information found for %s - S%sE%s' % (show_info['name'], season, episode)
                dialogs.ok(title, msg)
                return
            else:
                msg = 'No TMDb information found for %s - S%sE%s' % (show_info['name'], season, episode)
                dialogs.ok(title, msg)
                return
        if trakt_ids != None: params[lang].update(trakt_ids)
        params[lang]['info'] = show_info
        params[lang] = text.to_unicode(params[lang])
    link = play_base.on_play_video(players, params, trakt_ids)
    if link:
        properties.set_property('data', json.dumps({'dbid': dbid, 'trakt': id, 'season': season, 'episode': episode}))
        episode_metadata = meta_info.get_episode_metadata_trakt(season_info, prepisode)
        play_base.action_play({'label': episode_info['title'],
                               'path': link,
                               'info': episode_info,
                               'is_playable': True,
                               'info_type': 'video',
                               'thumbnail': episode_info['poster'],
                               'poster': episode_info['poster'],
                               'properties': {'fanart_image': str(show_info['fanart'])}})

def tvmaze_play_episode(id, season, episode, title=None):
    title = ''
    try: id = int(id)
    except: title = id
    if title and title != '':
        url = 'https://api.tvmaze.com/search/shows?q=%s' % id
        response = urllib.urlopen(url)
        shows = json.loads(response.read())
        if len(shows) > 0:
            show = shows[0]
            id = show['show']['id']
    url = 'https://api.tvmaze.com/shows/%d?embed[]=seasons&embed[]=episodes' % int(id)
    response = urllib.urlopen(url)
    show = json.loads(response.read())
    season = int(season)
    episode = int(episode)
    dbid = xbmc.getInfoLabel('ListItem.DBID')
    try: dbid = int(dbid)
    except: dbid = None
    if show['externals']:
        if show['externals']['thetvdb']: trakt_ids = play_base.get_trakt_ids('tvdb', show['externals']['thetvdb'], show['name'], 'show', show['premiered'][:4])
        elif show['externals']['imdb']: trakt_ids = play_base.get_trakt_ids('imdb', show['externals']['imdb'], show['name'], 'show', show['premiered'][:4])
        else: trakt_ids = play_base.get_trakt_ids(query=show['name'], type='show', year=show['premiered'][:4])
    else: trakt_ids = play_base.get_trakt_ids(query=show['name'], type='show', year=show['premiered'][:4])
    show_info = meta_info.get_tvshow_metadata_tvmaze(show)
    preasons = show['_embedded']['seasons']
    for item in preasons:
        if item['number'] == season: 
            preason = item
            season = preasons.index(item) + 1
        elif item['premiereDate'] and item['endDate']:
            if int(item['premiereDate'][:4]) <= season and int(item['endDate'][:4]) >= season: 
                preason = item
                season = preasons.index(item) + 1
    prepisodes = show['_embedded']['episodes']
    for item in prepisodes:
        if item['number'] == episode: prepisode = item
    season_info = meta_info.get_season_metadata_tvmaze(show_info, preason)
    episode_info = meta_info.get_episode_metadata_tvmaze(season_info, prepisode)
    if show_info['poster'] != None and show_info['poster'] != '': show_poster = show_info['poster']
    else: show_poster = ''
    if show_info['fanart'] != None and show_info['fanart'] != '': show_fanart = show_info['fanart']
    else: show_fanart = ''
    items = []
    play_plugin = meta_players.ADDON_SELECTOR.id
    players = meta_players.get_players('tvshows')
    players = [p for p in players if p.id == play_plugin] or players
    if not players: return xbmc.executebuiltin('Action(Info)')
    params = {}
    for lang in meta_players.get_needed_langs(players):
        if show['name'] is None: continue
        episode_parameters = get_tvmaze_episode_parameters(show, preason, prepisode)
        if episode_parameters is not None: params[lang] = episode_parameters
        else:
            title = 'Episode information not found'
            if trakt_ids['tmdb'] != None and trakt_ids['tmdb'] != '' and tried != 'tmdb': 
                tried = 'tmdb'
                return tvdb_play_episode(trakt_ids['tvdb'], season, episode)
            elif tried == 'tmdb':
                msg = 'No TVDb or TMDb information found for %s - S%sE%s' % (show_info['name'], season, episode)
                dialogs.ok('Episode information not found', msg)
                return
            else:
                msg = 'No TMDb information found for %s - S%sE%s' % (show_info['name'], season, episode)
                dialogs.ok('Episode information not found', msg)
                return
        if trakt_ids != None: params[lang].update(trakt_ids)
        params[lang]['info'] = show_info
        params[lang] = text.to_unicode(params[lang])
    link = play_base.on_play_video(players, params, trakt_ids)
    if link:
        properties.set_property('data', json.dumps({'dbid': dbid, 'tvdb': trakt_ids['tvdb'], 'season': season, 'episode': episode}))
        episode_metadata = meta_info.get_episode_metadata_tvmaze(season_info, prepisode)
        play_base.action_play({'label': episode_info['title'],
                               'path': link,
                               'info': [],
                               'is_playable': True,
                               'info_type': 'video',
                               'thumbnail': episode_info['poster'],
                               'poster': episode_info['poster'],
                               'properties': {'fanart_image': str(show_info['fanart'])}})

def get_episode_parameters(show, season, episode):
    from resources.lib.TheMovieDB import Find
    articles = ['a ', 'A ', 'An ', 'an ', 'The ', 'the ']
    if season in show and episode in show[season]:
        season_obj = show[season]
        episode_obj = show[season][episode]
    else: return
    parameters = {'id': show['id'], 'season': season, 'episode': episode}
    show_info = meta_info.get_tvshow_metadata_tvdb(show, banners=True)
    network = show.get('network', '')
    parameters['network'] = network
    if network: parameters['network_clean'] = re.sub('(\(.*?\))', '', network).strip()
    else: parameters['network_clean'] = network
    parameters['showname'] = show['seriesname'].replace('&', '%26')
    parameters['clearname'] = re.sub('(\(.*?\))', '', show['seriesname']).strip()
    parameters['stripname'] = ' '.join(re.compile('[\W_]+').sub(' ', show['seriesname']).split())
    parameters['sortname'] = text.to_utf8(parameters['clearname'])
    for article in articles:
        if text.to_utf8(parameters['clearname']).startswith(article): parameters['sortname'] = text.to_utf8(parameters['clearname']).replace(article,'')
    parameters['urlname'] = urllib.quote(text.to_utf8(parameters['clearname']))
    articles = ['a ', 'A ', 'An ', 'an ', 'The ', 'the ']
    parameters['sortname'] = text.to_utf8(parameters['clearname'])
    for article in articles:
        if text.to_utf8(parameters['clearname']).startswith(article): parameters['sortname'] = text.to_utf8(parameters['clearname']).replace(article,'')
    parameters['shortname'] = text.to_utf8(parameters['clearname'][1:-1])
    try: parameters['absolute_number'] = int(episode_obj.get('absolute_number'))
    except: parameters['absolute_number'] = 'na'
    parameters['title'] = episode_obj.get('episodename', str(episode)).replace('&', '%26')
    parameters['urltitle'] = urllib.quote(text.to_utf8(parameters['title']))
    parameters['sorttitle'] = text.to_utf8(parameters['title'])
    for article in articles:
        if text.to_utf8(parameters['title']).startswith(article): parameters['sorttitle'] = text.to_utf8(parameters['title']).replace(article,'')
    parameters['shorttitle'] = text.to_utf8(parameters['title'][1:-1])
    parameters['firstaired'] = episode_obj.get('firstaired')
    parameters['year'] = show.get('year', 0)
    if parameters['firstaired']:
        parameters['epyear'] = int(parameters['firstaired'].split('-')[0].strip())
        parameters['epmonth'] = int(parameters['firstaired'].split('-')[1].strip())
        parameters['epday'] = int(parameters['firstaired'].split('-')[2].strip())
    else:
        parameters['epyear'] = 1980
        parameters['epmonth'] = 0
        parameters['epday'] = 0
    parameters['imdb'] = show.get('imdb_id', '')
    parameters['epid'] = episode_obj.get('id')
    if episode_obj.get('id') != '': parameters['plot'] = episode_obj.get('overview').replace(':','').replace(';', '').replace('"', '')
    else: parameters['plot'] = show['overview'].replace(':','').replace(';', '').replace('"', '')
    if episode_obj.get('Rating') != '': parameters['rating'] = episode_obj.get('Rating')
    else: parameters['rating'] = show['Rating']
    if episode_obj.get('RatingCount') != '': parameters['votes'] = episode_obj.get('RatingCount')
    else: parameters['votes'] = show['RatingCount']
    parameters['writers'] = episode_obj.get('Writer')
    parameters['directors'] = episode_obj.get('Director')
    parameters['status'] = show.get('status')
    parameters['mpaa'] = show.get('ContentRating')
    if show.get('actors') != None and show.get('actors') != '': parameters['actors'] = re.sub(r'\<[^)].*?\>', '', show.get('actors'))
    else: parameters['actors'] = ''
    if show.get('genre') != None and '|' in show.get('genre'): parameters['genres'] = show.get('genre').replace('|',' / ')[3:-3]
    else: parameters['genres'] = show.get('Genre')
    parameters['runtime'] = show['runtime']
    parameters['duration'] = int(show['runtime']) * 60
    tvdb_base = 'https://thetvdb.com/banners/'
    if episode_obj.get('filename') != '': parameters['thumbnail'] = tvdb_base + str(episode_obj.get('filename'))
    elif show.get('poster') != '': parameters['thumbnail'] = show.get('poster')
    if show.get('poster') != '' and show.get('poster') is not None: parameters['poster'] = show.get('poster')
    parameters['thumbnail'] = tvdb_base + 'episodes/' + str(show['id']) + '/' + str(parameters['epid']) + '.jpg'
    parameters['banner'] = show.get('banner')
    if show.get('fanart') != None and show.get('fanart') != '': parameters['fanart'] = show.get('fanart')
    else: parameters['fanart'] = get_background_path()
    is_anime = False
    if parameters['genres'] != None and parameters['absolute_number'] and parameters['absolute_number'] != '0' and 'animation' in parameters['genres'].lower():
        tmdb_results = Find(show['id']).info(external_source='tvdb_id')
        for tmdb_show in tmdb_results.get('tv_results', []):
            if 'JP' in tmdb_show['origin_country']: is_anime = True
    if is_anime: parameters['name'] = u'{showname} {absolute_number}'.format(**parameters)
    else: parameters['name'] = u'{showname} S{season:02d}E{episode:02d}'.format(**parameters)
    parameters['now'] = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')
    trakt_ids = play_base.get_trakt_ids('tvdb', show['id'], parameters['clearname'], 'show', parameters['year'])
    if 'slug' in trakt_ids:
        if trakt_ids['slug'] != '' and trakt_ids['slug'] != None: parameters['slug'] = trakt_ids['slug']
        else: parameters['slug'] = parameters['clearname'].lower().replace('~','').replace('#','').replace('%','').replace('&','').replace('*','').replace('{','').replace('}','').replace('\\','').replace(':','').replace('<','').replace('>','').replace('?','').replace('/','').replace('+','').replace('|','').replace('"','').replace(' ','-')
    return parameters

def get_tmdb_episode_parameters(show, preason, prepisode):
    if 'status_code' in str(prepisode): return None
    parameters = {'id': show['external_ids']['tvdb_id'], 'season': preason['season_number'], 'episode': prepisode['episode_number']}
    network = show['networks'][0]['name']
    parameters['network'] = network
    if network: parameters['network_clean'] = re.sub('(\(.*?\))', '', network).strip()
    else: parameters['network_clean'] = network
    parameters['imdb'] = show['external_ids']['imdb_id']
    parameters['tmdb'] = show['id']
    parameters['showname'] = show['name']
    parameters['clearname'] = re.sub('(\(.*?\))', '', show['name']).strip()
    parameters['urlname'] = urllib.quote(text.to_utf8(parameters['clearname']))
    articles = ['a ', 'A ', 'An ', 'an ', 'The ', 'the ']
    parameters['sortname'] = text.to_utf8(parameters['clearname'])
    for article in articles:
        if text.to_utf8(parameters['clearname']).startswith(article): parameters['sortname'] = text.to_utf8(parameters['clearname']).replace(article,'')
    parameters['shortname'] = text.to_utf8(parameters['clearname'][1:-1])
    parameters['absolute_number'] = 'na'
    parameters['title'] = prepisode['name']
    parameters['urltitle'] = urllib.quote(text.to_utf8(parameters['title']))
    parameters['sorttitle'] = text.to_utf8(parameters['title'])
    articles = ['a ', 'A ', 'An ', 'an ', 'The ', 'the ']
    for article in articles:
        if text.to_utf8(parameters['title']).startswith(article): parameters['sorttitle'] = text.to_utf8(parameters['title']).replace(article,'')
    parameters['shorttitle'] = text.to_utf8(parameters['title'][1:-1])
    parameters['firstaired'] = prepisode['air_date']
    parameters['year'] = int(show['first_air_date'].split('-')[0].strip())
    if parameters['firstaired']:
        parameters['epyear'] = int(parameters['firstaired'].split('-')[0].strip())
        parameters['epmonth'] = int(parameters['firstaired'].split('-')[1].strip())
        parameters['epday'] = int(parameters['firstaired'].split('-')[2].strip())
    else:
        parameters['epyear'] = 1900
        parameters['epmonth'] = 0
        parameters['epday'] = 0
    parameters['epid'] = prepisode['id']
    if preason['episodes'][0] != None and preason['episodes'][0] != '' and preason['episodes'][0] != []: parameters['poster'] = u'https://image.tmdb.org/t/p/w500%s' % preason['episodes'][0]['still_path']
    elif show['poster_path'] != None and show['poster_path'] != '' and show['poster_path'] != []: parameters['poster'] = u'https://image.tmdb.org/t/p/w500%s' % show['poster_path']
    if show['backdrop_path'] != None and show['backdrop_path'] != '' and show['backdrop_path'] != []: parameters['fanart'] = u'https://image.tmdb.org/t/p/original%s' % show['backdrop_path']
    else: parameters['fanart'] = ''
    parameters['thumbnail'] = parameters['poster']
    parameters['icon'] = parameters['poster']
    try: genre = [x for x in show['genre'].split('|') if not x == '']
    except: genre = ''
    parameters['genre'] = ' / '.join(genre)
    if 'JP' in show['origin_country']: is_anime = True
    else: is_anime = False
    if is_anime: parameters['name'] = u'{showname} {absolute_number}'.format(**parameters)
    else: parameters['name'] = u'{showname} S{season:02d}E{episode:02d}'.format(**parameters)
    parameters['now'] = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')
    return parameters

def get_trakt_episode_parameters(show, preason, prepisode):
    if 'status_code' in str(prepisode): return None
    parameters = {'id': show['external_ids']['tvdb_id'], 'season': preason['season_number'], 'episode': prepisode['episode_number']}
    network = show['networks'][0]['name']
    parameters['network'] = network
    if network: parameters['network_clean'] = re.sub('(\(.*?\))', '', network).strip()
    else: parameters['network_clean'] = network
    parameters['imdb'] = show['external_ids']['imdb_id']
    parameters['tmdb'] = show['id']
    parameters['showname'] = show['name']
    parameters['clearname'] = re.sub('(\(.*?\))', '', show['name']).strip()
    parameters['urlname'] = urllib.quote(text.to_utf8(parameters['clearname']))
    articles = ['a ', 'A ', 'An ', 'an ', 'The ', 'the ']
    parameters['sortname'] = text.to_utf8(parameters['clearname'])
    for article in articles:
        if text.to_utf8(parameters['clearname']).startswith(article): parameters['sortname'] = text.to_utf8(parameters['clearname']).replace(article,'')
    parameters['shortname'] = text.to_utf8(parameters['clearname'][1:-1])
    parameters['absolute_number'] = 'na'
    parameters['title'] = prepisode['name']
    parameters['urltitle'] = urllib.quote(text.to_utf8(parameters['title']))
    parameters['sorttitle'] = text.to_utf8(parameters['title'])
    articles = ['a ', 'A ', 'An ', 'an ', 'The ', 'the ']
    for article in articles:
        if text.to_utf8(parameters['title']).startswith(article): parameters['sorttitle'] = text.to_utf8(parameters['title']).replace(article,'')
    parameters['shorttitle'] = text.to_utf8(parameters['title'][1:-1])
    parameters['firstaired'] = prepisode['air_date']
    parameters['year'] = int(show['first_air_date'].split('-')[0].strip())
    if parameters['firstaired']:
        parameters['epyear'] = int(parameters['firstaired'].split('-')[0].strip())
        parameters['epmonth'] = int(parameters['firstaired'].split('-')[1].strip())
        parameters['epday'] = int(parameters['firstaired'].split('-')[2].strip())
    else:
        parameters['epyear'] = 1900
        parameters['epmonth'] = 0
        parameters['epday'] = 0
    parameters['epid'] = prepisode['id']
    if preason['episodes'][0] != None and preason['episodes'][0] != '' and preason['episodes'][0] != []: parameters['poster'] = u'https://image.tmdb.org/t/p/w500%s' % preason['episodes'][0]['still_path']
    elif show['poster_path'] != None and show['poster_path'] != '' and show['poster_path'] != []: parameters['poster'] = u'https://image.tmdb.org/t/p/w500%s' % show['poster_path']
    if show['backdrop_path'] != None and show['backdrop_path'] != '' and show['backdrop_path'] != []: parameters['fanart'] = u'https://image.tmdb.org/t/p/original%s' % show['backdrop_path']
    else: parameters['fanart'] = ''
    parameters['thumbnail'] = parameters['poster']
    parameters['icon'] = parameters['poster']
    try: genre = [x for x in show['genre'].split('|') if not x == '']
    except: genre = ''
    parameters['genre'] = ' / '.join(genre)
    if 'JP' in show['origin_country']: is_anime = True
    else: is_anime = False
    if is_anime: parameters['name'] = u'{showname} {absolute_number}'.format(**parameters)
    else: parameters['name'] = u'{showname} S{season:02d}E{episode:02d}'.format(**parameters)
    parameters['now'] = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')
    return parameters

def get_tvmaze_episode_parameters(show, preason, prepisode):
    if 'status_code' in str(prepisode): return None
    parameters = {'id': show['externals']['thetvdb'], 'season': preason['number'], 'episode': prepisode['number']}
    network = show['network']['name']
    parameters['network'] = network
    if network: parameters['network_clean'] = re.sub('(\(.*?\))', '', network).strip()
    else: parameters['network_clean'] = network
    parameters['imdb'] = show['externals']['imdb']
    parameters['tvrage'] = show['externals']['tvrage']
    parameters['showname'] = show['name']
    parameters['clearname'] = re.sub('(\(.*?\))', '', show['name']).strip()
    parameters['urlname'] = urllib.quote(text.to_utf8(parameters['clearname']))
    articles = ['a ', 'A ', 'An ', 'an ', 'The ', 'the ']
    parameters['sortname'] = text.to_utf8(parameters['clearname'])
    for article in articles:
        if text.to_utf8(parameters['clearname']).startswith(article): parameters['sortname'] = text.to_utf8(parameters['clearname']).replace(article,'')
    parameters['shortname'] = text.to_utf8(parameters['clearname'][1:-1])
    parameters['absolute_number'] = 'na'
    parameters['title'] = prepisode['name']
    parameters['urltitle'] = urllib.quote(text.to_utf8(parameters['title']))
    parameters['sorttitle'] = text.to_utf8(parameters['title'])
    articles = ['a ', 'A ', 'An ', 'an ', 'The ', 'the ']
    for article in articles:
        if text.to_utf8(parameters['title']).startswith(article): parameters['sorttitle'] = text.to_utf8(parameters['title']).replace(article,'')
    parameters['shorttitle'] = text.to_utf8(parameters['title'][1:-1])
    parameters['firstaired'] = prepisode['airdate']
    parameters['year'] = int(show['premiered'].split('-')[0].strip())
    if parameters['firstaired']:
        parameters['epyear'] = int(parameters['firstaired'].split('-')[0].strip())
        parameters['epmonth'] = int(parameters['firstaired'].split('-')[1].strip())
        parameters['epday'] = int(parameters['firstaired'].split('-')[2].strip())
    else:
        parameters['epyear'] = 1900
        parameters['epmonth'] = 0
        parameters['epday'] = 0
    parameters['epid'] = prepisode['id']
    if prepisode['image'] != None: parameters['poster'] = prepisode['image']['original']
    elif preason['image'] != None: parameters['poster'] = preason['image']['original']
    elif show['image'] != None: parameters['poster'] = show['image']['original']
    parameters['fanart'] = ''
    parameters['thumbnail'] = parameters['poster']
    parameters['icon'] = parameters['poster']
    parameters['genre'] = show['type']
    parameters['now'] = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')
    return parameters