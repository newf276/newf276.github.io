import xbmc, xbmcgui, xbmcplugin
import os
from sys import argv
import json
try: from urllib import urlencode
except ImportError: from urllib.parse import urlencode
from modules.nav_utils import build_url, setView, show_text, notification
from modules.utils import to_utf8, safe_string, remove_accents
from modules.utils import local_string as ls
from modules import settings
# from modules.utils import logger

addon_dir = xbmc.translatePath('special://home/addons/plugin.video.fen/')

tmdb_api = settings.tmdb_api_check()
icon_directory = settings.get_theme()
dialog = xbmcgui.Dialog()
window = xbmcgui.Window(10000)

class Discover:
	def __init__(self, params):
		self.view = 'view.main'
		self.icon = os.path.join(icon_directory, 'discover.png')
		self.fanart = os.path.join(addon_dir, 'fanart.png')
		self.db_type = params.get('db_type', None)
		self.key = params.get('key', None)
		if self.db_type: self.window_id = 'FEN_%s_discover_params' % self.db_type.upper()
		else: self.window_id = ''
		try: self.discover_params = json.loads(window.getProperty(self.window_id))
		except: self.discover_params = {}
		self.base_str = '[B]%s:[/B]  [I]%s[/I]'
		self.include_base_str = '%s %s' % (ls(32188), '%s')
		self.exclude_base_str = '%s %s' % (ls(32189), '%s')
		self.heading_base = '%s %s - %s' % (ls(32036), ls(32451), '%s')

	def movie(self):
		self._set_default_params('movie')
		names = self.discover_params['search_name']
		self._add_dir({'mode': 'discover._clear_property', 'db_type': 'movie', 'list_name': '[B]%s[/B]' % ls(32656).upper()})
		if not 'recommended' in names: self._add_dir({'mode': 'discover.similar_recommended', 'db_type': 'movie', 'key': 'similar', 'list_name': '[B]%s %s:[/B]  [I]%s[/I]' % (ls(32451), ls(32592), names.get('similar', ''))})
		if not 'similar' in names: self._add_dir({'mode': 'discover.similar_recommended', 'db_type': 'movie', 'key': 'recommended', 'list_name': '[B]%s %s:[/B]  [I]%s[/I]' % (ls(32451), ls(32593), names.get('recommended', ''))})
		if not any(i in names for i in ['similar', 'recommended']):
			self._add_dir({'mode': 'discover.year_start', 'db_type': 'movie', 'list_name': self.base_str % ('%s %s' % (ls(32543), ls(32654)), names.get('year_start', ''))})
			self._add_dir({'mode': 'discover.year_end', 'db_type': 'movie', 'list_name': self.base_str % ('%s %s' % (ls(32543), ls(32655)), names.get('year_end', ''))})
			self._add_dir({'mode': 'discover.include_genres', 'db_type': 'movie', 'list_name': self.base_str % (self.include_base_str % ls(32470), names.get('include_genres', ''))})
			self._add_dir({'mode': 'discover.exclude_genres', 'db_type': 'movie', 'list_name': self.base_str % (self.exclude_base_str % ls(32470), names.get('exclude_genres', ''))})
			self._add_dir({'mode': 'discover.include_keywords', 'db_type': 'movie', 'list_name': self.base_str % (self.include_base_str % ls(32657), names.get('include_keywords', ''))})
			self._add_dir({'mode': 'discover.exclude_keywords', 'db_type': 'movie', 'list_name': self.base_str % (self.exclude_base_str % ls(32657), names.get('exclude_keywords', ''))})
			self._add_dir({'mode': 'discover.language', 'db_type': 'movie', 'list_name': self.base_str % (ls(32658), names.get('language', ''))})
			self._add_dir({'mode': 'discover.region', 'db_type': 'movie', 'list_name': self.base_str % (ls(32659), names.get('region', ''))})
			self._add_dir({'mode': 'discover.companies', 'db_type': 'movie', 'list_name': self.base_str % (ls(32660), names.get('companies', ''))})
			self._add_dir({'mode': 'discover.certification', 'db_type': 'movie', 'list_name': self.base_str % (ls(32473), names.get('certification', ''))})
			self._add_dir({'mode': 'discover.rating', 'db_type': 'movie', 'list_name': self.base_str % ('%s %s' % (ls(32661), ls(32621)), names.get('rating', ''))})
			self._add_dir({'mode': 'discover.rating_votes', 'db_type': 'movie', 'list_name': self.base_str % ('%s %s' % (ls(32661), ls(32663)), names.get('rating_votes', ''))})
			self._add_dir({'mode': 'discover.cast', 'db_type': 'movie', 'list_name': self.base_str % (self.include_base_str % ls(32664), names.get('cast', ''))})
			self._add_dir({'mode': 'discover.sort_by', 'db_type': 'movie', 'list_name': self.base_str % (ls(32067), names.get('sort_by', ''))})
			self._add_dir({'mode': 'discover.adult', 'db_type': 'movie', 'list_name': self.base_str % (self.include_base_str % ls(32665), names.get('adult', ls(32860)))})
		self._add_defaults()
		self._end_directory()

	def tvshow(self):
		self._set_default_params('tvshow')
		names = self.discover_params['search_name']
		self._add_dir({'mode': 'discover._clear_property', 'db_type': 'tvshow', 'list_name': '[B]%s[/B]' % ls(32656).upper()})
		if not 'recommended' in names: self._add_dir({'mode': 'discover.similar_recommended', 'db_type': 'tvshow', 'key': 'similar', 'list_name': '[B]%s %s:[/B]  [I]%s[/I]' % (ls(32451), ls(32592), names.get('similar', ''))})
		if not 'similar' in names: self._add_dir({'mode': 'discover.similar_recommended', 'db_type': 'tvshow', 'key': 'recommended', 'list_name': '[B]%s %s:[/B]  [I]%s[/I]' % (ls(32451), ls(32593), names.get('recommended', ''))})
		if not any(i in names for i in ['similar', 'recommended']):
			self._add_dir({'mode': 'discover.year_start', 'db_type': 'tvshow', 'list_name': self.base_str % ('%s %s' % (ls(32543), ls(32654)), names.get('year_start', ''))})
			self._add_dir({'mode': 'discover.year_end', 'db_type': 'tvshow', 'list_name': self.base_str % ('%s %s' % (ls(32543), ls(32655)), names.get('year_end', ''))})
			self._add_dir({'mode': 'discover.include_genres', 'db_type': 'tvshow', 'list_name': self.base_str % (self.include_base_str % ls(32470), names.get('include_genres', ''))})
			self._add_dir({'mode': 'discover.exclude_genres', 'db_type': 'tvshow', 'list_name': self.base_str % (self.exclude_base_str % ls(32470), names.get('exclude_genres', ''))})
			self._add_dir({'mode': 'discover.include_keywords', 'db_type': 'tvshow', 'list_name': self.base_str % (self.include_base_str % ls(32657), names.get('include_keywords', ''))})
			self._add_dir({'mode': 'discover.exclude_keywords', 'db_type': 'tvshow', 'list_name': self.base_str % (self.exclude_base_str % ls(32657), names.get('exclude_keywords', ''))})
			self._add_dir({'mode': 'discover.language', 'db_type': 'tvshow', 'list_name': self.base_str % (ls(32658), names.get('language', ''))})
			self._add_dir({'mode': 'discover.network', 'db_type': 'tvshow', 'list_name': self.base_str % (ls(32480), names.get('network', ''))})
			self._add_dir({'mode': 'discover.rating', 'db_type': 'tvshow', 'list_name': self.base_str % ('%s %s' % (ls(32661), ls(32621)), names.get('rating', ''))})
			self._add_dir({'mode': 'discover.rating_votes', 'db_type': 'tvshow', 'list_name': self.base_str % ('%s %s' % (ls(32661), ls(32663)), names.get('rating_votes', ''))})
			self._add_dir({'mode': 'discover.sort_by', 'db_type': 'tvshow', 'list_name': self.base_str % (ls(32067), names.get('sort_by', ''))})
		self._add_defaults()
		self._end_directory()

	def similar_recommended(self):
		key = self.key
		if self._action(key) in ('clear', None): return
		title = dialog.input(self.heading_base % ls(32228)).lower()
		if not title: return
		if self.db_type == 'movie':
			from apis.tmdb_api import tmdb_movies_title_year as function
		else:
			from apis.tmdb_api import tmdb_tv_title_year as function
		year = dialog.input(self.heading_base % ('%s (%s)' % (ls(32543), ls(32669))), type=xbmcgui.INPUT_NUMERIC)
		results = function(title, year)['results']
		if len(results) == 0: return notification(ls(32490))
		choice_list = []
		for item in results:
			title = item['title'] if self.db_type == 'movie' else item['name']
			try: year = item['release_date'].split('-')[0] if self.db_type == 'movie' else item['first_air_date'].split('-')[0]
			except: year = ''
			if year: rootname = '%s (%s)' % (title, year)
			else: rootname = title
			line1 = rootname
			line2 = '[I]%s[/I]' % item['overview']
			icon = 'https://image.tmdb.org/t/p/w92%s' % item['poster_path'] if item.get('poster_path') else xbmc.translatePath(settings.addon().getAddonInfo('icon'))
			listitem = xbmcgui.ListItem(line1, line2)
			listitem.setArt({'icon': icon})
			listitem.setProperty('rootname', rootname)
			listitem.setProperty('tmdb_id', str(item['id']))
			choice_list.append(listitem)
		chosen_title = dialog.select(self.heading_base % ('%s %s' % (ls(32193), ls(32228))), choice_list, useDetails=True)
		if chosen_title < 0: return
		rootname = choice_list[chosen_title].getProperty('rootname')
		tmdb_id = choice_list[chosen_title].getProperty('tmdb_id')
		values = (tmdb_id, rootname)
		self._process(key, values)

	def include_keywords(self):
		key = 'include_keywords'
		if self._action(key) in ('clear', None): return
		current_key_ids = self.discover_params['search_string'].get(key, [])
		current_keywords = self.discover_params['search_name'].get(key, [])
		if not isinstance(current_key_ids, list):
			current_key_ids = current_key_ids.replace('&with_keywords=', '').split(', ')
		if not isinstance(current_keywords, list):
			current_keywords = current_keywords.split(', ')
		keyword = dialog.input(self.heading_base % (self.include_base_str % ls(32657)))
		if keyword:
			from apis.tmdb_api import tmdb_keyword_id
			try:
				result = tmdb_keyword_id(keyword)['results']
				keywords_choice = self._multiselect_dialog(self.heading_base % ('%s %s' % (ls(32193), ls(32657))), [i['name'].upper() for i in result], result)
				if keywords_choice:
					for i in keywords_choice:
						current_key_ids.append(str(i['id']))
						current_keywords.append(i['name'].upper())
			except: pass
			values = ('&with_keywords=%s' % ','.join([i for i in current_key_ids]), ', '.join([i for i in current_keywords]))
			self._process(key, values)

	def exclude_keywords(self):
		key = 'exclude_keywords'
		if self._action(key) in ('clear', None): return
		current_key_ids = self.discover_params['search_string'].get(key, [])
		current_keywords = self.discover_params['search_name'].get(key, [])
		if not isinstance(current_key_ids, list):
			current_key_ids = current_key_ids.split(', ')
		if not isinstance(current_keywords, list):
			current_keywords = current_keywords.split(', ')
		keyword = dialog.input(self.heading_base % (self.exclude_base_str % ls(32657)))
		if keyword:
			from apis.tmdb_api import tmdb_keyword_id
			try:
				result = tmdb_keyword_id(keyword)['results']
				keywords_choice = self._multiselect_dialog(self.heading_base % ('%s %s' % (ls(32193), ls(32657))), [i['name'].upper() for i in result], result)
				if keywords_choice:
					for i in keywords_choice:
						current_key_ids.append(str(i['id']))
						current_keywords.append(i['name'].upper())
			except: pass
			values = ('&without_keywords=%s' % ','.join([i for i in current_key_ids]), ', '.join([i for i in current_keywords]))
			self._process(key, values)

	def year_start(self):
		key = 'year_start'
		if self._action(key) in ('clear', None): return
		from modules.nav_utils import years
		years = years()
		years_list = [str(i) for i in years]
		year_start = self._selection_dialog(years_list, years, self.heading_base % ('%s %s' % (ls(32654), ls(32543))))
		if year_start:
			if self.discover_params['db_type'] == 'movie':
				value = 'primary_release_date.gte'
			else:
				value = 'first_air_date.gte'
			values = ('&%s=%s-01-01' % (value, str(year_start)), str(year_start))
			self._process(key, values)

	def year_end(self):
		key = 'year_end'
		if self._action(key) in ('clear', None): return
		from modules.nav_utils import years
		years = years()
		years_list = [str(i) for i in years]
		year_end = self._selection_dialog(years_list, years, self.heading_base % ('%s %s' % (ls(32655), ls(32543))))
		if year_end:
			if self.discover_params['db_type'] == 'movie':
				value = 'primary_release_date.lte'
			else:
				value = 'first_air_date.lte'
			values = ('&%s=%s-12-31' % (value, str(year_end)), str(year_end))
			self._process(key, values)

	def include_genres(self):
		key = 'include_genres'
		if self._action(key) in ('clear', None): return
		if self.discover_params['db_type'] == 'movie':
			from modules.nav_utils import movie_genres as genres
		else:
			from modules.nav_utils import tvshow_genres as genres
		genre_list = [(k, v[0]) for k,v in sorted(genres().items())]
		genres_choice = self._multiselect_dialog(self.heading_base % (self.include_base_str % ls(32470)), [i[0] for i in genre_list], genre_list)
		if genres_choice:
			genre_ids = ','.join([i[1] for i in genres_choice])
			genre_names = ', '.join([i[0] for i in genres_choice])
			values = ('&with_genres=%s' % genre_ids, genre_names)
			self._process(key, values)

	def exclude_genres(self):
		key = 'exclude_genres'
		if self._action(key) in ('clear', None): return
		if self.discover_params['db_type'] == 'movie':
			from modules.nav_utils import movie_genres as genres
		else:
			from modules.nav_utils import tvshow_genres as genres
		genre_list = [(k, v[0]) for k,v in sorted(genres().items())]
		genres_choice = self._multiselect_dialog(self.heading_base % (self.exclude_base_str % ls(32470)), [i[0] for i in genre_list], genre_list)
		if genres_choice:
			genre_ids = ','.join([i[1] for i in genres_choice])
			genre_names = ', '.join([i[0] for i in genres_choice])
			values = ('&without_genres=%s' % genre_ids, '/'.join(genre_names.split(', ')))
			self._process(key, values)

	def language(self):
		key = 'language'
		if self._action(key) in ('clear', None): return
		from modules.nav_utils import languages
		languages_list = [i[0] for i in languages()]
		language = self._selection_dialog(languages_list, languages(), self.heading_base % ls(32658))
		if language:
			values = ('&with_original_language=%s' % str(language[1]), str(language[1]).upper())
			self._process(key, values)

	def region(self):
		key = 'region'
		if self._action(key) in ('clear', None): return
		from modules.nav_utils import regions
		region_names = [i['name'] for i in regions()]
		region_codes = [i['code'] for i in regions()]
		region = self._selection_dialog(region_names, region_codes, self.heading_base % ls(32659))
		if region:
			region_name = [i['name'] for i in regions() if i['code'] == region][0]
			values = ('&region=%s' % region, region_name)
			self._process(key, values)

	def rating(self):
		key = 'rating'
		if self._action(key) in ('clear', None): return
		ratings = [i for i in range(1,11)]
		ratings_list = [str(float(i)) for i in ratings]
		rating = self._selection_dialog(ratings_list, ratings, self.heading_base % ('%s %s' % (ls(32661), ls(32621))))
		if rating:
			values = ('&vote_average.gte=%s' % str(rating), str(float(rating)))
			self._process(key, values)

	def rating_votes(self):
		key = 'rating_votes'
		if self._action(key) in ('clear', None): return
		rating_votes = [i for i in range(0,1001,50)]
		rating_votes.pop(0)
		rating_votes.insert(0, 1)
		rating_votes_list = [str(i) for i in rating_votes]
		rating_votes = self._selection_dialog(rating_votes_list, rating_votes, self.heading_base % ('%s %s' % (ls(32661), ls(32663))))
		if rating_votes:
			values = ('&vote_count.gte=%s' % str(rating_votes), str(rating_votes))
			self._process(key, values)

	def certification(self):
		key = 'certification'
		if self._action(key) in ('clear', None): return
		from modules.nav_utils import movie_certifications as certifications
		certifications = certifications()
		certifications_list = [i.upper() for i in certifications]
		certification = self._selection_dialog(certifications_list, certifications, self.heading_base % ls(32473))
		if certification:
			values = ('&certification_country=US&certification=%s' % certification, certification.upper())
			self._process(key, values)

	def cast(self):
		key = 'cast'
		if self._action(key) in ('clear', None): return
		from apis.tmdb_api import get_tmdb
		from caches.fen_cache import cache_object
		result = None
		actor_id = None
		search_name = None
		search_name = dialog.input(self.heading_base % ls(32664), type=xbmcgui.INPUT_ALPHANUM)
		if not search_name: return
		string = "%s_%s" % ('tmdb_movies_people_search_actor_data', search_name)
		url = 'https://api.themoviedb.org/3/search/person?api_key=%s&language=en-US&query=%s' % (tmdb_api, search_name)
		result = cache_object(get_tmdb, string, url, 4)
		result = result['results']
		if not result: return
		actor_list = []
		if len(result) > 1:
			for item in result:
				name = item['name']
				known_for_list = [i.get('title', 'NA') for i in item['known_for']]
				known_for_list = [i for i in known_for_list if not i == 'NA']
				known_for = '[I]%s[/I]' % ', '.join(known_for_list) if known_for_list else ''
				listitem = xbmcgui.ListItem(name, known_for)
				listitem.setArt({'icon': 'https://image.tmdb.org/t/p/w185/%s' % item['profile_path']})
				listitem.setProperty('id', str(item['id']))
				listitem.setProperty('name', name)
				actor_list.append(listitem)
			selection = dialog.select(self.heading_base % ls(32664), actor_list, useDetails=True)
			if selection >= 0:
				actor_id = int(actor_list[selection].getProperty('id'))
				actor_name = actor_list[selection].getProperty('name')
			else:
				self._set_property()
		else:
			actor_id = [item['id'] for item in result][0]
			actor_name = [item['name'] for item in result][0]
		if actor_id:
			values = ('&with_cast=%s' % str(actor_id), to_utf8(safe_string(remove_accents(actor_name))))
			self._process(key, values)

	def network(self):
		key = 'network'
		if self._action(key) in ('clear', None): return
		from modules.nav_utils import networks
		network_list = []
		networks = sorted(networks(), key=lambda k: k['name'])
		for item in networks:
			name = item['name']
			listitem = xbmcgui.ListItem(name, iconImage=item['logo'])
			listitem.setProperty('id', str(item['id']))
			listitem.setProperty('name', name)
			network_list.append(listitem)
		selection = dialog.select(self.heading_base % ls(32480), network_list, useDetails=True)
		if selection >= 0:
			network_id = int(network_list[selection].getProperty('id'))
			network_name = network_list[selection].getProperty('name')
			values = ('&with_networks=%s' % network_id, network_name)
			self._process(key, values)

	def companies(self):
		key = 'companies'
		if self._action(key) in ('clear', None): return
		current_company_ids = self.discover_params['search_string'].get(key, [])
		current_companies = self.discover_params['search_name'].get(key, [])
		if not isinstance(current_company_ids, list):
			current_company_ids = current_company_ids.replace('&with_companies=', '').split('|')
		if not isinstance(current_companies, list):
			current_companies = current_companies.split(', ')
		company = dialog.input(self.heading_base % ls(32660))
		if company:
			from apis.tmdb_api import tmdb_company_id
			company_choice = None
			try:
				results = tmdb_company_id(company)
				if results['total_results'] == 0: return None
				if results['total_results'] == 1: company_choice = results['results']
				if not company_choice:
					results = results['results']
					company_choice = self._multiselect_dialog(self.heading_base % ls(32660), [i['name'].upper() for i in results], results)
				if company_choice:
					for i in company_choice:
						current_company_ids.append(str(i['id']))
						current_companies.append(i['name'].upper())
				values = ('&with_companies=%s' % '|'.join([i for i in current_company_ids]), ', '.join([i for i in current_companies]))
				self._process(key, values)
			except: pass

	def sort_by(self):
		key = 'sort_by'
		if self._action(key) in ('clear', None): return
		if self.discover_params['db_type'] == 'movie':
			sort_by_list = self._movies_sort()
		else:
			sort_by_list = self._tvshows_sort()
		sort_by_value = self._selection_dialog([i[0] for i in sort_by_list], [i[1] for i in sort_by_list], self.heading_base % ls(32067))
		if sort_by_value:
			sort_by_name = [i[0] for i in sort_by_list if i[1] == sort_by_value][0]
			values = (sort_by_value, sort_by_name)
			self._process(key, values)

	def adult(self):
		key = 'adult'
		include_adult = self._selection_dialog((ls(32859), ls(32860)), ('true', 'false'), self.heading_base % self.include_base_str % ls(32665))
		if include_adult:
			values = ('&include_adult=%s' % include_adult, include_adult.capitalize())
			self._process(key, values)

	def export(self):
		try:
			db_type = self.discover_params['db_type']
			query = self.discover_params['final_string']
			name = self.discover_params['name']
			set_history(db_type, name, query)
			if db_type == 'movie':
				mode = 'build_movie_list'
				action = 'tmdb_movies_discover'
			else:
				mode = 'build_tvshow_list'
				action = 'tmdb_tv_discover'
			final_params = {'name': name, 'mode': mode, 'action': action, 'query': query, 'iconImage': self.icon}
			url_params = {'mode': 'navigator.adjust_main_lists', 'method': 'add_external',
						'list_name': name, 'menu_item': json.dumps(final_params)}
			xbmc.executebuiltin('RunPlugin(%s)' % self._build_url(url_params))
		except:
			from modules.nav_utils import notification
			notification(ls(32574))

	def history(self, db_type=None, display=True):
		try: from sqlite3 import dbapi2 as database
		except ImportError: from pysqlite2 import dbapi2 as database
		__handle__ = int(argv[1])
		cache_file = xbmc.translatePath('special://profile/addon_data/plugin.video.fen/fen_cache2.db')
		db_type = db_type if db_type else self.db_type
		string = 'fen_discover_%s_%%' % db_type
		settings.check_database(cache_file)
		dbcon = database.connect(cache_file)
		dbcur = dbcon.cursor()
		dbcur.execute("SELECT id, data FROM fencache WHERE id LIKE ? ORDER BY rowid DESC", (string,))
		history = dbcur.fetchall()
		if not display: return [i[0] for i in history]
		data = [eval(i[1]) for i in history]
		export_str = ls(32697)
		remove_str = ls(32698)
		clear_str = ls(32699)
		for count, item in enumerate(data):
			try:
				cm = []
				data_id = history[count][0]
				name = item['name']
				url_params = {'mode': item['mode'], 'action': item['action'], 'query': item['query'],
							  'name': name, 'iconImage': self.icon}
				display = '%s | %s' % (count+1, name)
				url = build_url(url_params)
				remove_single_params = {'mode': 'discover.remove_from_history', 'data_id': data_id}
				remove_all_params = {'mode': 'discover.remove_all_history', 'db_type': db_type}
				export_params = {'mode': 'navigator.adjust_main_lists', 'method': 'add_external',
								'list_name': name, 'menu_item': json.dumps(url_params)}
				listitem = xbmcgui.ListItem(display)
				listitem.setArt({'icon': self.icon, 'poster': self.icon, 'thumb': self.icon, 'fanart': self.fanart, 'banner': self.icon})
				cm.append(("[B]%s[/B]" % export_str,'RunPlugin(%s)'% self._build_url(export_params)))
				cm.append(("[B]%s[/B]" % remove_str,'RunPlugin(%s)'% self._build_url(remove_single_params)))
				cm.append(("[B]%s[/B]" % clear_str,'RunPlugin(%s)'% self._build_url(remove_all_params)))
				listitem.addContextMenuItems(cm)
				xbmcplugin.addDirectoryItem(__handle__, url, listitem, isFolder=True)
			except: pass
		self._end_directory()

	def help(self):
		text_file = xbmc.translatePath(os.path.join(addon_dir, "resources", "text", "discover_help.txt"))
		return show_text(self.heading_base % ls(32487), text_file)

	def _set_default_params(self, db_type):
		if not 'db_type' in self.discover_params:
			self._clear_property()
			url_db_type = 'movie' if db_type == 'movie' else 'tv'
			param_db_type = 'Movies' if db_type == 'movie' else 'TV Shows'
			self.discover_params['db_type'] = db_type
			self.discover_params['search_string'] = {}
			self.discover_params['search_string']['base'] = 'https://api.themoviedb.org/3/discover/%s?api_key=%s&language=en-US&page=%s' % (url_db_type, tmdb_api, '%s')
			self.discover_params['search_string']['base_similar'] = 'https://api.themoviedb.org/3/%s/%s/similar?api_key=%s&language=en-US&page=%s' % (url_db_type, '%s', tmdb_api, '%s')
			self.discover_params['search_string']['base_recommended'] = 'https://api.themoviedb.org/3/%s/%s/recommendations?api_key=%s&language=en-US&page=%s' % (url_db_type, '%s', tmdb_api, '%s')
			self.discover_params['search_name'] = {'db_type': param_db_type}
			self._set_property()

	def _add_defaults(self):
		if self.discover_params['db_type'] == 'movie':
			mode = 'build_movie_list'
			action = 'tmdb_movies_discover'
		else:
			mode = 'build_tvshow_list'
			action = 'tmdb_tv_discover'
		name = self.discover_params.get('name', '...')
		query = self.discover_params.get('final_string', '')
		self._add_dir({'mode': mode, 'action': action, 'query': query, 'name': name, 'list_name': ls(32666) % name}, isFolder=True, icon=os.path.join(icon_directory, 'search.png'))
		self._add_dir({'mode': 'discover.export', 'db_type': self.db_type, 'list_name': ls(32667) % name}, icon=os.path.join(icon_directory, 'nextpage.png'))

	def _action(self, key):
		dict_item = self.discover_params
		add_to_list = ('keyword', 'companies')
		action = ls(32602) if any(word in key for word in add_to_list) else ls(32668)
		if key in dict_item['search_name']:
			action = self._selection_dialog([action.capitalize(), ls(32671)], (action, 'clear'), self.heading_base % ls(32670))
		if action is None: return
		if action == 'clear':
			index = self._listitem_position(key)
			for k in ('search_string', 'search_name'): dict_item[k].pop(key, None)
			self._process(index=index)
		return action

	def _process(self, key=None, values=None, index=None):
		if key:
			index = self._listitem_position(key)
			self.discover_params['search_string'][key] = values[0]
			self.discover_params['search_name'][key] = values[1]
		self._build_string()
		self._build_name()
		self._set_property()
		xbmc.executebuiltin('Container.Refresh')
		if index: self._focus_index(index)

	def _clear_property(self):
		window.clearProperty(self.window_id)
		self.discover_params = {}
		xbmc.executebuiltin('Container.Refresh')

	def _set_property(self):
		return window.setProperty(self.window_id, json.dumps(self.discover_params))

	def _add_dir(self, params, isFolder=False, icon=None):
		__handle__ = int(argv[1])
		icon = self.icon if not icon else icon
		list_name = params.get('list_name', '')
		url = self._build_url(params)
		listitem = xbmcgui.ListItem(list_name)
		listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': self.fanart, 'banner': icon})
		xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=listitem, isFolder=isFolder)

	def _end_directory(self):
		__handle__ = int(argv[1])
		xbmcplugin.setContent(__handle__, 'addons')
		xbmcplugin.endOfDirectory(__handle__)
		setView(self.view, 'addons')

	def _build_url(self, query):
		return argv[0] + '?' + urlencode(to_utf8(query))

	def _selection_dialog(self, dialog_list, function_list, string):
		list_choose = dialog.select(string, dialog_list)
		if list_choose >= 0: return function_list[list_choose]
		else: return None

	def _multiselect_dialog(self, string, dialog_list, function_list=None, preselect= []):
		if not function_list: function_list = dialog_list
		list_choose = dialog.multiselect(string, dialog_list, preselect=preselect)
		if list_choose:
			return [function_list[i] for i in list_choose]
		else:
			return

	def _build_string(self):
		string_params = self.discover_params['search_string']
		if 'similar' in string_params:
			string = string_params['base_similar'] % (string_params['similar'], '%s')
			self.discover_params['final_string'] = string
			return
		if 'recommended' in string_params:
			string = string_params['base_recommended'] % (string_params['recommended'], '%s')
			self.discover_params['final_string'] = string
			return
		string = string_params['base']
		if 'year_start' in string_params:
			string += string_params['year_start']
		if 'year_end' in string_params:
			string += string_params['year_end']
		if 'include_genres' in string_params:
			string += string_params['include_genres']
		if 'exclude_genres' in string_params:
			string += string_params['exclude_genres']
		if 'include_keywords' in string_params:
			string += string_params['include_keywords']
		if 'exclude_keywords' in string_params:
			string += string_params['exclude_keywords']
		if 'companies' in string_params:
			string += string_params['companies']
		if 'language' in string_params:
			string += string_params['language']
		if 'region' in string_params:
			string += string_params['region']
		if 'rating' in string_params:
			string += string_params['rating']
		if 'rating_votes' in string_params:
			string += string_params['rating_votes']
		if 'certification' in string_params:
			string += string_params['certification']
		if 'cast' in string_params:
			string += string_params['cast']
		if 'network' in string_params:
			string += string_params['network']
		if 'adult' in string_params:
			string += string_params['adult']
		if 'sort_by' in string_params:
			string += string_params['sort_by']
		self.discover_params['final_string'] = string

	def _build_name(self):
		values = self.discover_params['search_name']
		db_type = values['db_type']
		db_name = ls(32028) if db_type == 'Movies' else ls(32029)
		name = '[B]%s[/B] ' % db_name
		if 'similar' in values:
			name += '| %s %s' % (ls(32672), values['similar'])
			self.discover_params['name'] = name
			return
		if 'recommended' in values:
			name += '| %s %s' % (ls(32673), values['recommended'])
			self.discover_params['name'] = name
			return
		if 'year_start' in values:
			if 'year_end' in values and not values['year_start'] == values['year_end']:
				name += '| %s' % values['year_start']
			else:
				name += '| %s ' % values['year_start']
		if 'year_end' in values:
			if 'year_start' in values:
				if not values['year_start'] == values['year_end']:
					name += '-%s ' % values['year_end']
			else:
				name += '| %s ' % values['year_end']
		if 'language' in values:
			name += '| %s ' % values['language']
		if 'region' in values:
			name += '| %s ' % values['region']
		if 'network' in values:
			name += '| %s ' % values['network']
		if 'include_genres' in values:
			name += '| %s ' % values['include_genres']
			if 'exclude_genres' in values:
				name += '(%s %s) ' % (ls(32189).lower(), values['exclude_genres'])
		elif 'exclude_genres' in values:
			name += '| %s %s ' % (ls(32189).lower(), values['exclude_genres'])
		if 'companies' in values:
			name += '| %s ' % values['companies']
		if 'certification' in values:
			name += '| %s ' % values['certification']
		if 'rating' in values:
			name += '| %s+ ' % values['rating']
			if 'rating_votes' in values:
				name += '(%s) ' % values['rating_votes']
		elif 'rating_votes' in values:
			name += '| %s+ %s ' % (values['rating_votes'], ls(32623).lower())
		if 'cast' in values:
			name += '| %s %s ' % (ls(32664).lower(), values['cast'])
		if 'include_keywords' in values:
			name += '| %s %s: %s ' % (ls(32188).lower(), ls(32657).lower(), values['include_keywords'])
		if 'exclude_keywords' in values:
			name += '| %s %s: %s ' % (ls(32189).lower(), ls(32657).lower(), values['exclude_keywords'])
		if 'sort_by' in values:
			name += '| %s ' % values['sort_by']
		if 'adult' in values:
			if values['adult'] == ls(32859): name += '| %s %s ' % (ls(32188).lower(), ls(32665).lower())
		self.discover_params['name'] = name

	def _listitem_position(self, key):
		if key in ('similar', 'recommended'): return 0
		if key == 'year_start': return 3
		if key == 'year_end': return 4
		if key == 'include_genres': return 5
		if key == 'exclude_genres': return 6
		if key == 'include_keywords': return 7
		if key == 'exclude_keywords': return 8
		if key == 'language': return 9
		if key in ('region', 'network'): return 10
		if key == 'companies': return 11
		if key == 'certification': return 12
		if key == 'rating':
			if self.db_type == 'movie': return 13
			else: return 11
		if key == 'rating_votes':
			if self.db_type == 'movie': return 14
			else: return 12
		if key == 'cast': return 15
		if key == 'sort_by':
			if self.db_type == 'movie': return 16
			else: return 13
		if key == 'adult': return 17
		return None

	def _focus_index(self, index):
		xbmc.sleep(500)
		current_window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
		focus_id = current_window.getFocusId()
		try: current_window.getControl(focus_id).selectItem(index)
		except: pass

	def _movies_sort(self):
		pop_str, rel_str, rev_str, tit_str, rat_str, asc_str, desc_str = ls(32218), ls(32221), ls(32626), ls(32228), ls(32621), ls(32224), ls(32225)
		return [
			('%s (%s)' % (pop_str, asc_str), '&sort_by=popularity.asc'),
			('%s (%s)' % (pop_str, desc_str), '&sort_by=popularity.desc'),
			('%s (%s)' % (rel_str, asc_str), '&sort_by=primary_release_date.asc'),
			('%s (%s)' % (rel_str, desc_str), '&sort_by=primary_release_date.desc'),
			('%s (%s)' % (rev_str, asc_str), '&sort_by=revenue.asc'),
			('%s (%s)' % (rev_str, desc_str), '&sort_by=revenue.desc'),
			('%s (%s)' % (tit_str, asc_str), '&sort_by=original_title.asc'),
			('%s (%s)' % (tit_str, desc_str), '&sort_by=original_title.desc'),
			('%s (%s)' % (rat_str, asc_str), '&sort_by=vote_average.asc'),
			('%s (%s)' % (rat_str, desc_str), '&sort_by=vote_average.desc')
				]

	def _tvshows_sort(self):
		pop_str, prem_str, rat_str, asc_str, desc_str = ls(32218), ls(32620), ls(32621), ls(32224), ls(32225)
		return [
			('%s (%s)' % (pop_str, asc_str), '&sort_by=popularity.asc'),
			('%s (%s)' % (pop_str, desc_str), '&sort_by=popularity.desc'),
			('%s (%s)' % (prem_str, asc_str), '&sort_by=first_air_date.asc'),
			('%s (%s)' % (prem_str, desc_str), '&sort_by=first_air_date.desc'),
			('%s (%s)' % (rat_str, asc_str), '&sort_by=vote_average.asc'),
			('%s (%s)' % (rat_str, desc_str), '&sort_by=vote_average.desc')
			]

def set_history(db_type, name, query):
	from caches import fen_cache
	from datetime import timedelta
	_cache = fen_cache.FenCache()
	string = 'fen_discover_%s_%s' % (db_type, query)
	cache = _cache.get(string)
	if cache: return
	if db_type == 'movie':
		mode = 'build_movie_list'
		action = 'tmdb_movies_discover'
	else:
		mode = 'build_tvshow_list'
		action = 'tmdb_tv_discover'
	data = {'mode': mode, 'action': action, 'name': name, 'query': query}
	_cache.set(string, data, expiration=timedelta(days=7))
	return

def remove_from_history(params):
	try: from sqlite3 import dbapi2 as database
	except ImportError: from pysqlite2 import dbapi2 as database
	from modules.nav_utils import notification
	cache_file = xbmc.translatePath('special://profile/addon_data/plugin.video.fen/fen_cache2.db')
	settings.check_database(cache_file)
	dbcon = database.connect(cache_file)
	dbcur = dbcon.cursor()
	dbcur.execute("DELETE FROM fencache WHERE id=?", (params['data_id'],))
	dbcon.commit()
	window.clearProperty(params['data_id'])
	xbmc.executebuiltin("Container.Refresh")
	if not params['silent']: notification(ls(32576))

def remove_all_history(params):
	from modules.nav_utils import notification
	db_type = params['db_type']
	heading_base = '%s %s - %s' % (ls(32036), ls(32451), '%s')
	if not dialog.yesno('Fen', heading_base % ls(32580)): return
	all_history = Discover({}).history(db_type, display=False)
	for item in all_history:
		remove_from_history({'data_id': item, 'silent': True})
	notification(ls(32576))
