## Theme for Chinook & Auramod users
                  SmartPlay PopUp             
![nextup up popup](https://i.imgur.com/dsaUpuE.jpg)

|                   Scraping                   |                   Source Select                   |
|:--------------------------------------------:|:-------------------------------------------------:|
| ![Scraping](https://i.imgur.com/wZukP7n.jpg) | ![Source Select](https://i.imgur.com/sqgtzXg.png) |

|                    Resolving                  |                Provider Manager                      |
|:---------------------------------------------:|:----------------------------------------------------:|
| ![Resolving](https://i.imgur.com/ADKZ16Y.png) | ![Provider Manager](https://i.imgur.com/TagHvjP.png) |


##### Requirements
* Chinook - 2.x or greater
* AuraMod - Latest Repo version or higher 

**This theme Has not been tested and won't be supported on any skin besides AuraMod , use at your on risk with other skins.**

*The text color for this theme is controlled by Chinooks  Settings called "Select Text Highlight Color..." Found in Chinook Settings > Interface*

-----------

##### To install this theme in Chinook, navigate to:

`Chinook -> Tools > Open Settings Menu -> Theme Manager -> Interface > (themes section) Install Theme -> Web Location`

And enter one of the following URL:
http://bit.ly/chinookmodfull
or

https://www.github.com/SerpentDrago/ChinookTheme-ChinookMod-Full/zipball/master/

------------


You can also download the `.zip` file directly from the same URL, and install it from:

`Chinook -> Tools > Open Settings Menu -> Theme Manager -> Interface > (themes section) Install Theme ->  Browse`

------------




*The creator of this theme is not affiliated with Chinook, Arctic Zephyr 2, or Kodi.*

