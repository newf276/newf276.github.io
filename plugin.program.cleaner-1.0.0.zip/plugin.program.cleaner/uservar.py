'''#####-----Build File-----#####'''
buildfile = 'https://www'

'''#####-----Videos File-----#####'''
videos_url = 'https://youtu.be/DO_W22vggGE'

'''#####-----Notification File-----#####'''
notify_url = ''

'''#####-----Changelog Directory-----#####'''
changelog_dir = 'https://github.com/%s/%s/raw/master/packages/%s'

'''#####-----Excludes-----#####'''
excludes = ['plugin.video.whatever']
